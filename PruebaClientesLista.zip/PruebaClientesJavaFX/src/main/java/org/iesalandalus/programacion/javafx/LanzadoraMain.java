package org.iesalandalus.programacion.javafx;

public class LanzadoraMain {

	public static void main(String[] args) {
		Main.main(args);
	}

}
